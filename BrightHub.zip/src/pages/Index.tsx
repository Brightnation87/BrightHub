import Landing from "./Landing";

const Index = () => {
  return <Landing />;
};

export default Index;
